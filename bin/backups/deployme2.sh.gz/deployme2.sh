#! /bin/sh

WL=${1}
IP_SERVER_PORT=${2}
ACTION=${3}
COMP=${4}
PATH_ORIGIN=${5}
TARG=${6}

# ----------------------------------------------------------------------------------------------------------------------------------
# -- IF JUST EXECUTE deployme.sh
# ----------------------------------------------------------------------------------------------------------------------------------

if [ "${WL}" = "" ]
 then
     echo "Examples : \
                       
                 DEPLOY>> 
                           sh deploy.sh 'wl10' '10.103.12.151:9001' 'deploy' 'FillOrderWeb.war' '/var/samba/public/VERSIONES/Componentes_E2E/NOE/FillOrderWeb.war' 'clust01' \

                 UNDEPLOY>>
                           sh deploy.sh 'wl10' '10.103.12.151:9001' 'undeploy' 'FillOrderWeb.war' \

                 START>>
                            sh deploy.sh 'wl10' '10.103.12.151:9001' 'start' 'FillOrderWeb.war' \

                 STOP>>
                            sh deploy.sh 'wl10' '10.103.12.151:9001' 'stop' 'FillOrderWeb.war'  "
fi


# ----------------------------------------------------------------------------------------------------------------------------------
# -- IF EXECUTE deployme.sh with parameters
# ----------------------------------------------------------------------------------------------------------------------------------

if [ "${WL}" = "wl10" ]
 then
	export WL_HOME="/opt/apps/wl10mp3/bea/wlserver_10.3"
	export BEA_HOME="/opt/apps/wl10mp3/bea/user_projects/domains/wlsnxt"
	export JAVA_HOME="/opt/java6/bin"
	export CLASSPATH=$WL_HOME/server/lib/weblogic.jar:$CLASSPATH
	export PATH=$WL_HOME/server/lib/weblogic.jar:$PATH
	export PATH=$JAVA_HOME:$PATH

      		 if [ "${ACTION}" = "deploy" ]
         		then    
                                
          			java weblogic.Deployer -adminurl t3://${IP_SERVER_PORT} -user admin -password xxx -deploy -name ${COMP} -source ${PATH_ORIGIN} -targets ${TARG} -stage 
       		 fi

        	if [ "${ACTION}" = "undeploy" ]
         		then    
                                cp ${BEA_HOME}/
           			java weblogic.Deployer -adminurl t3://${IP_SERVER_PORT} -user admin -password xxx -undeploy -name ${COMP}
        	fi

        	if [ "${ACTION}" = "start" ]
         		then
           			java weblogic.Deployer -adminurl t3://${IP_SERVER_PORT} -user admin -password xxx -start -name ${COMP}
        	fi

        	if [ "${ACTION}" = "stop" ]
         		then
          			java weblogic.Deployer -adminurl t3://${IP_SERVER_PORT} -user admin -password xxx -stop -name ${COMP} 
        	fi
fi


if [ "${WL}" = "wl9" ]
 then
        export WL_HOME="/opt/apps/wl9mp2/bea/weblogic92"
        export BEA_HOME=" /opt/apps/wl9mp2/bea/user_projects/domains"
        export JAVA_HOME="/opt/java1.5/bin"
        export CLASSPATH=$WL_HOME/server/lib/weblogic.jar:$CLASSPATH
        export PATH=$WL_HOME/server/lib/weblogic.jar:$PATH
        export PATH=$JAVA_HOME:$PATH

                 if [ "${ACTION}" = "deploy" ]
                        then
                                java weblogic.Deployer -adminurl t3://${IP_SERVER_PORT} -user admin -password fff -deploy -name ${COMP} -source ${PATH_ORIGIN} -targets ${TARG} -stage
                 fi     

                if [ "${ACTION}" = "undeploy" ]
                        then
                                java weblogic.Deployer -adminurl t3://${IP_SERVER_PORT} -user admin -password fff -undeploy -name ${COMP}
                fi

                if [ "${ACTION}" = "start" ]
                        then
                                java weblogic.Deployer -adminurl t3://${IP_SERVER_PORT} -user admin -password fff -start -name ${COMP}
                fi

                if [ "${ACTION}" = "stop" ]
                        then
                                java weblogic.Deployer -adminurl t3://${IP_SERVER_PORT} -user admin -password fff -stop -name ${COMP}
                fi      
fi


#java weblogic.Deployer -help

#java weblogic.Deployer -examples

#java weblogic.Deployer -adminurl t3://10.103.12.151:9001 -user admin -password xxx -deploy -name FillOrderWeb.war -source /opt/apps/nxtcomp/201106061341/FillOrderWeb.war -targets clust02 -stage

#java weblogic.Deployer -adminurl t3://10.103.12.151:9001 -userconfigfile myuserconfigfile.secure -userkeyfile keyfile.secure -stop -name FillOrderWeb.war

#java weblogic.Deployer -adminurl t3://10.103.12.151:9001 -userconfigfile myuserconfigfile.secure -userkeyfile keyfile.secure -start -name FillOrderWeb.war

#java weblogic.Deployer -adminurl t3://10.103.12.151:9001 -user admin -password xxx -stop -name FillOrderWeb

#java weblogic.Deployer -adminurl t3://10.103.12.151:9001 -user admin -password xxx -undeploy -name FillOrderWeb.war

