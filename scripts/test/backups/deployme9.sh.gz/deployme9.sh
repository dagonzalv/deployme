#! /bin/sh

#	export WL_HOME="/opt/apps/wl10mp3/bea/wlserver_10.3"
#	export BEA_HOME="/opt/apps/wl10mp3/bea/user_projects/domains"
#	export JAVA_HOME="/opt/java6/bin"
#	export CLASSPATH=$WL_HOME/server/lib/weblogic.jar:$CLASSPATH
#	export PATH=$WL_HOME/server/lib/weblogic.jar:$PATH
#	export PATH=$JAVA_HOME:$PATH


        export WL_HOME="/opt/apps/wl9mp2/bea/weblogic92"
        export BEA_HOME=" /opt/apps/wl9mp2/bea/user_projects/domains"
        export JAVA_HOME="/opt/java1.5/bin"
        export CLASSPATH=$WL_HOME/server/lib/weblogic.jar:$CLASSPATH
        export PATH=$WL_HOME/server/lib/weblogic.jar:$PATH
        export PATH=$JAVA_HOME:$PATH



java weblogic.Deployer -advanced

#java weblogic.Deployer -examples

#java weblogic.Deployer -adminurl t3://10.103.12.151:9001 -user admin -password  -deploy -name FillOrderWeb.war -source /opt/apps/nxtcomp/201106061341/FillOrderWeb.war -targets clust02 -stage

#java weblogic.Deployer -adminurl t3://10.103.12.151:9001 -userconfigfile myuserconfigfile.secure -userkeyfile keyfile.secure -stop -name FillOrderWeb.war

#java weblogic.Deployer -adminurl t3://10.103.12.151:7101 -user admin -password  -deploy -name siscob.war -source /opt/apps/nxtcomp/pruebas/201108090213/siscob.war -targets svmsco01 -stage

#java weblogic.Deployer -adminurl t3://10.103.12.151:7101 -user admin -password  -start -name siscob

#java weblogic.Deployer -adminurl t3://10.103.12.151:9001 -user admin -password  -stop -name FillOrderWeb

#java weblogic.Deployer -adminurl t3://10.103.12.151:9001 -user admin -password -undeploy -name FillOrderWeb.war
